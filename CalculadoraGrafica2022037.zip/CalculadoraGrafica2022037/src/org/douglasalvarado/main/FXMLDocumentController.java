/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.douglasalvarado.main;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 *
 * @author informatica
 */
public class FXMLDocumentController implements Initializable {
    
    double valor1 ,valor2 ,result;
    int opcion, conteo, div;
    boolean punto = false;
    
    @FXML private TextField txtPantalla;
    @FXML private Button btnMasMenos;
    @FXML private Button btnCero;
    @FXML private Button btnPunto;
    @FXML private Button btnIgual;
    @FXML private Button btnUno;
    @FXML private Button btnDos;
    @FXML private Button btnTres;
    @FXML private Button btnSuma;
    @FXML private Button btnCuatro;
    @FXML private Button btnCinco;
    @FXML private Button btnSeis;
    @FXML private Button btnResta;
    @FXML private Button btnSiete;
    @FXML private Button btnOcho;
    @FXML private Button btnNueve;
    @FXML private Button btnMulti;
    @FXML private Button btnUnoX;
    @FXML private Button btnCuadrado;
    @FXML private Button btnRaiz;
    @FXML private Button btnDivi;
    @FXML private Button btnPorciento;
    @FXML private Button btnCE;
    @FXML private Button btnC;
    @FXML private Button btnOFF;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
        if(event.getSource() == btnMasMenos){
            valor1 = Double.parseDouble(txtPantalla.getText());
            if (valor1 > 0) {
                txtPantalla.setText("-"+valor1);
            }else if(valor1 < 0){
                txtPantalla.setText(String.valueOf(valor1).substring(1));
            }else{
                txtPantalla.setText("0");
            }
        }

        if(event.getSource() == btnPunto){
            if((txtPantalla.getText()).equals("") ){
                txtPantalla.setText("0.");
            }else{
                if (punto == false) {
                    txtPantalla.setText(txtPantalla.getText() + ".");
                }
            }
            punto = true;
            conteo = 0;
        }

        if(event.getSource() == btnCero)
            punto(0);
        if(event.getSource() == btnUno)
            punto(1);
        if(event.getSource() == btnDos)  
            punto(2);
        if(event.getSource() == btnTres)
            punto(3);
        if(event.getSource() == btnCuatro)
            punto(4);
        if(event.getSource() == btnCinco)
            punto(5);
        if(event.getSource() == btnSeis)
            punto(6);
        if(event.getSource() == btnSiete)
            punto(7);
        if(event.getSource() == btnOcho)
            punto(8);
        if(event.getSource() == btnNueve)
            punto(9);
        
        if(event.getSource() == btnSuma){
            if (valor1 == 0) {
                valor1 = Double.parseDouble(txtPantalla.getText());
                opcion = 1;
                conteo = 0;
                txtPantalla.setText("");
            }else if(valor2 == 0){
                valor1 = valor1 + Double.parseDouble(txtPantalla.getText());
                opcion = 1;
                conteo = 0;
                txtPantalla.setText("");
            }else{
                valor1 = valor1 + valor2;
                opcion = 1;
                conteo = 0;
                txtPantalla.setText("");
            }    
        }
                
        if(event.getSource() == btnResta){
            if (valor1 == 0) {
                valor1 = Double.parseDouble(txtPantalla.getText());
                opcion = 2;
                conteo = 0;
                txtPantalla.setText("");
            }else if(valor2 == 0){
                valor1 = valor1 - Double.parseDouble(txtPantalla.getText());
                opcion = 2;
                conteo = 0;
                txtPantalla.setText("");
            }else{
                valor1 = valor1 - valor2;
                opcion = 2;
                conteo = 0;
                txtPantalla.setText("");
            }   
        }
        
        
        if(event.getSource() == btnMulti){
            valor1 = Double.parseDouble(txtPantalla.getText());
            opcion = 3;
            conteo = 0;
            txtPantalla.setText("");
        }
        
        if(event.getSource() == btnDivi){
            valor1 = Double.parseDouble(txtPantalla.getText());
            opcion = 4;
            conteo = 0;
            txtPantalla.setText("");
        }
        
        if(event.getSource() == btnCuadrado){
            valor1 = Double.parseDouble(txtPantalla.getText());
            result = valor1 * valor1;            
            txtPantalla.setText(String.valueOf(result));
        }
        
        if(event.getSource() == btnRaiz){
            valor1 = Double.parseDouble(txtPantalla.getText());
            result = Math.sqrt(valor1);
            txtPantalla.setText(String.valueOf(result));
        }
        
        if(event.getSource() == btnPorciento){
            valor2 = 0;
            valor2 = (Double.parseDouble(txtPantalla.getText())*valor1 )/ 100;
            txtPantalla.setText(String.valueOf(valor2));
        }
        
        if(event.getSource() == btnUnoX){
            valor1 = Double.parseDouble(txtPantalla.getText());
            txtPantalla.setText(String.valueOf(1 / valor1));
        }
        
        if(event.getSource() == btnCE){
            txtPantalla.setText("");
            punto = false;
        } 
        
        if(event.getSource() == btnC){
            txtPantalla.setText("");
            punto = false;
            valor1 = 0;
        }   
        
        if(event.getSource() == btnOFF)
            System.exit(1);
        
        if (event.getSource() == btnIgual) {
                valor2 = Double.parseDouble(txtPantalla.getText());
                txtPantalla.setText("");
                switch (opcion) {
                    case 1:
                        result = valor1 + valor2;
                        break;
                    case 2: 
                        result = valor1 - valor2;
                        break;
                    case 3: 
                        result = valor1 * valor2;
                        break;
                    case 4: 
                        if (valor2 == 0) {
                            result = 0;
                        }else
                            result = valor1 / valor2;
                        break;
                    default:
                        result = 0;
                        throw new AssertionError();
                }
            if ((result == 0 && valor2 == 0) || (result == 0 && valor1 == 0)){
                txtPantalla.setText("No dividir 0");
                div = 1;                
            } 
            else
                txtPantalla.setText(String.valueOf(result));    
        }
    }
    
    private void punto(int numero){
        if(punto == true){
            if (conteo <= 1 ) {
                txtPantalla.setText(txtPantalla.getText() + numero);
                conteo = conteo + 1;
            }else
                txtPantalla.setText(txtPantalla.getText());
        }else
            txtPantalla.setText(txtPantalla.getText() + numero);
            
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
